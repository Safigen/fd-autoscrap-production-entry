# @safi_ai/fd-sdk

Child-side postMessage bridge for Guidewheel forward-deployed apps. Provides a typed API for communicating with the Guidewheel host frame — so FD app developers never call `postMessage` directly.

## Installation

```bash
npm install @safi_ai/fd-sdk
```

Requires `react` >= 18 as a peer dependency.

## Usage

### BridgeProvider

Mount once at your app root to activate the bridge. It listens for `fd:context` from the host and keeps the iframe title in sync:

```tsx
import { BridgeProvider } from "@safi_ai/fd-sdk";

export default function App() {
  return (
    <BridgeProvider>
      <YourApp />
    </BridgeProvider>
  );
}
```

### bridge singleton

Use the `bridge` singleton for direct postMessage calls:

```ts
import { bridge } from "@safi_ai/fd-sdk";

// Notify the host that the session has expired
bridge.notifySessionExpired();

// Update the title displayed above the iframe
bridge.setTitle("My App Title");

// Receive user context injected by the host (company, username, locale, appName)
const cleanup = bridge.onContext((ctx) => {
  console.log(ctx.company, ctx.username);
});
// Call cleanup() to remove the listener
```

> **Note:** `fd:context` is display-only — never use it for authorization. Auth is always enforced server-side via the `fd_session` cookie.

## API

### `bridge.notifySessionExpired()`

Posts `{ type: "fd:session_expired" }` to the parent frame. The Guidewheel host handles this by prompting the user to relaunch the app.

### `bridge.setTitle(title: string)`

Posts `{ type: "fd:set_title", payload: { title } }` to the parent frame to update the label shown above the iframe.

### `bridge.onContext(cb: (ctx: FdContextPayload) => void): () => void`

Registers a listener for `fd:context` messages sent by the host after the iframe loads. Returns a cleanup function. Only accepts messages from `window.parent`.

### `BridgeProvider`

React component that mounts `onContext` and sets the iframe title from `ctx.appName`. Renders nothing (`null`).

## Types

```ts
type FdContextPayload = {
  company: string;
  username: string;
  locale: string;
  appName: string;
};
```
