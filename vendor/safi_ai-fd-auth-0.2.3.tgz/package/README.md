# @safi_ai/fd-auth

Auth middleware and session utilities for Guidewheel forward-deployed apps. Handles the launch token exchange, session cookie lifecycle, and authenticated API clients for dataProxy and safi-api-service.

## Installation

```bash
npm install @safi_ai/fd-auth
```

Requires `next` >= 14 as a peer dependency.

## Usage

### Middleware

Replace your `middleware.ts` with:

```ts
import { createFdAuthMiddleware } from "@safi_ai/fd-auth";

export default createFdAuthMiddleware({
  dataProxyUrl: process.env.DATA_PROXY_URL!,
});

export const config = {
  matcher: ["/((?!_next/static|_next/image|favicon.ico).*)"],
};
```

The middleware handles:
- Detecting `?launch_token=` and exchanging it with dataProxy for an access token
- Setting an `fd_session` HTTP-only cookie (CHIPS-compatible for cross-site iframes)
- Redirecting to the clean URL after token exchange
- Guarding routes: 401 for API routes, redirect to `/unauthenticated` for pages

### Reading the session

```ts
import { getSession } from "@safi_ai/fd-auth";

export default async function MyPage() {
  const session = await getSession();
  // session.company, session.username, session.accessToken
}
```

### Authenticated dataProxy client

```ts
import { createDataProxyClient } from "@safi_ai/fd-auth";

export default async function MyPage() {
  const client = await createDataProxyClient();
  const res = await client.get("/api/v2/some-endpoint");
  const data = await res.json();
  return <div>{JSON.stringify(data)}</div>;
}
```

For client components, create an API route that uses `createDataProxyClient()` and fetch from that route in the client.

### Authenticated safi-api-service client

```ts
import { createSafiApiClient } from "@safi_ai/fd-auth";

export default async function MyPage() {
  const client = await createSafiApiClient();
  const res = await client.get("/v1/companies/acme/devices", {
    from_ts: "1700000000000",
    to_ts: "1700086400000",
  });
  const data = await res.json();
  return <div>{JSON.stringify(data)}</div>;
}
```

Auth is via Bearer token from the FD session — no API key required.

## Configuration

`createFdAuthMiddleware` accepts:

| Option | Default | Description |
|--------|---------|-------------|
| `dataProxyUrl` | *required* | Base URL for the dataProxy API |
| `cookieName` | `"fd_session"` | Cookie name |
| `validatePath` | `"/api/v2/fd-auth/validate"` | Validation endpoint path |
| `unauthenticatedPath` | `"/unauthenticated"` | Redirect path for unauthenticated requests |
| `maxAge` | `28800` (8h) | Cookie max age in seconds |
| `cookieOptions.secure` | `true` | Secure flag |
| `cookieOptions.sameSite` | `"none"` | SameSite attribute |
| `cookieOptions.partitioned` | `true` | CHIPS partitioned attribute |
| `loginUrl` | `undefined` | Login gateway URL for standalone (non-iframe) access. When set, unauthenticated users are redirected here with `redirect_uri` instead of to `/unauthenticated`. e.g. `"https://auth.safi.today/login"` |
| `company` | `undefined` | Company ID passed to the login gateway as a query param to pre-fill the company field |

## Migrating from inline auth

If your FD app has inline `middleware.ts`, `lib/auth.ts`, and `lib/data-proxy.ts`:

1. `npm install @safi_ai/fd-auth`
2. Replace `middleware.ts` with the 7-line version above
3. Replace `import { getSession } from "@/lib/auth"` with `import { getSession } from "@safi_ai/fd-auth"`
4. Replace `import { createDataProxyClient } from "@/lib/data-proxy"` with `import { createDataProxyClient } from "@safi_ai/fd-auth"`
5. Delete `lib/auth.ts` and `lib/data-proxy.ts`
