import React from 'react'
import { createRoot } from 'react-dom/client'
import { FdProvider } from '@safi_ai/fd-app/provider'
import App from 'APP_ENTRY'

class ErrorBoundary extends React.Component<
  { children: React.ReactNode },
  { error: Error | null }
> {
  constructor(props: { children: React.ReactNode }) {
    super(props)
    this.state = { error: null }
  }

  static getDerivedStateFromError(error: Error) {
    return { error }
  }

  render() {
    if (this.state.error) {
      return (
        <div style={{ fontFamily: 'system-ui, sans-serif', padding: '2rem', maxWidth: '600px', margin: '2rem auto' }}>
          <h1 style={{ fontSize: '1.25rem', color: '#b91c1c', marginBottom: '0.5rem' }}>Something went wrong</h1>
          <pre style={{ fontSize: '0.75rem', color: '#6b7280', background: '#f9fafb', padding: '1rem', borderRadius: '4px', overflow: 'auto', whiteSpace: 'pre-wrap' }}>
            {this.state.error.message}
          </pre>
        </div>
      )
    }
    return this.props.children
  }
}

createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <ErrorBoundary>
      <FdProvider>
        <App />
      </FdProvider>
    </ErrorBoundary>
  </React.StrictMode>
)
