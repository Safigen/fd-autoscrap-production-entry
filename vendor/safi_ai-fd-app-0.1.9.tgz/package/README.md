# @safi_ai/fd-app

Platform package for Guidewheel forward-deployed apps. Provides the Hono server (auth middleware, safi-api proxy, dataProxy proxy), React client hooks, and the `fd-app` CLI for dev/build/start.

## Installation

```bash
npm install @safi_ai/fd-app
```

Requires `react` >= 18 and `react-dom` >= 18 as peer dependencies.

## Environment Variables

| Variable | Required | Description |
|----------|----------|-------------|
| `DATA_PROXY_URL` | Yes | Base URL for the dataProxy API |
| `SAFI_API_URL` | Yes | Base URL for safi-api-service |
| `NPM_TOKEN` | Yes (build-time) | npm auth token for `@safi_ai` packages |
| `FD_LOGIN_URL` | No | Login gateway URL for standalone (non-iframe) access |
| `FD_COMPANY` | No | Pre-selects company on the login gateway redirect |

## Server

### `createFdApp()`

Creates a Hono app with auth, session, safi-api proxy, and dataProxy proxy pre-wired:

```ts
import { createFdApp } from "@safi_ai/fd-app/server";

const app = createFdApp();
export default app;
```

Built-in routes:

| Route | Description |
|-------|-------------|
| `GET /healthz` | Health check — no auth required |
| `GET /api/session` | Returns `{ company, username }` for the current session |
| `* /api/safi/*` | Proxies to `SAFI_API_URL` with Bearer token auth |
| `* /api/proxy/*` | Proxies to `DATA_PROXY_URL` with Bearer token auth |

Auth flow: on first load, the Guidewheel host appends `?launch_token=` to the URL. The middleware exchanges this with dataProxy for an access + refresh token, sets an `fd_session` HTTP-only cookie, and redirects to the clean URL. Subsequent requests are authenticated via the cookie.

Custom routes can be added after `createFdApp()`:

```ts
const app = createFdApp();

app.get("/api/my-route", async (c) => {
  return c.json({ hello: "world" });
});
```

## Client

### `FdProvider`

Wrap your app root. Fetches the session on mount, renders a "Session expired" screen if unauthenticated, and makes session data available via `useFdSession`:

```tsx
import { FdProvider } from "@safi_ai/fd-app";

export default function App() {
  return (
    <FdProvider>
      <YourApp />
    </FdProvider>
  );
}
```

### Hooks

```ts
import { useFdSession, useSafiApi, useDataProxy, useFullscreen } from "@safi_ai/fd-app";

// Current session info
const session = useFdSession(); // { company, username } | null

// Fetch from safi-api-service (via /api/safi/*)
const { data, loading, error } = useSafiApi("/v1/companies/acme/devices", {
  from_ts: "1700000000000",
  to_ts: "1700086400000",
});

// Fetch from dataProxy (via /api/proxy/*)
const { data, loading, error } = useDataProxy("/api/v2/some-endpoint");

// Manage fullscreen mode (useful for kiosk/TV displays)
const { isFullscreen, toggleFullscreen, supportsFullscreen } = useFullscreen();
```

All `useSafiApi` and `useDataProxy` params must be strings.

### `bridge`

Re-exported from `@safi_ai/fd-sdk` for convenience:

```ts
import { bridge } from "@safi_ai/fd-app";

bridge.notifySessionExpired();
bridge.setTitle("My App");
```

## CLI

The `fd-app` CLI is available after install:

```bash
fd-app dev     # Start Vite dev server + Hono backend
fd-app build   # Production build
fd-app start   # Start production server
```

In `package.json`:

```json
{
  "scripts": {
    "dev": "fd-app dev",
    "build": "fd-app build",
    "start": "fd-app start"
  }
}
```
